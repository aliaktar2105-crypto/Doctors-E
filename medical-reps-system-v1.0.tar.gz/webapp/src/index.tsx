import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import { renderer } from './renderer'
import type { Bindings } from './types'
import { login, createSession, verifySession } from './auth'
import {
  getDoctors,
  addDoctor,
  updateDoctor,
  getSpecialties,
  getRegions,
  getDashboardStats,
  getVisitPlans,
  addVisitPlan
} from './database'

const app = new Hono<{ Bindings: Bindings }>()

// إعداد CORS والملفات الثابتة
app.use('/api/*', cors())
app.use('/static/*', serveStatic({ root: './public' }))
app.use(renderer)

// API routes للمصادقة
app.post('/api/login', async (c) => {
  try {
    console.log('Login attempt started')
    const body = await c.req.json()
    console.log('Request body:', body)
    
    const { username, password } = body
    
    if (!username || !password) {
      console.log('Missing credentials')
      return c.json({ error: 'اسم المستخدم وكلمة المرور مطلوبان' }, 400)
    }
    
    console.log('Calling login function...')
    const rep = await login(c, username, password)
    console.log('Login result:', rep ? 'success' : 'failed')
    
    if (!rep) {
      return c.json({ error: 'بيانات تسجيل الدخول غير صحيحة' }, 401)
    }
    
    console.log('Creating session token...')
    const sessionToken = createSession(rep)
    
    return c.json({
      success: true,
      user: {
        id: rep.id,
        username: rep.username,
        name: rep.name,
        company: rep.company,
        region: rep.region
      },
      token: sessionToken
    })
  } catch (error) {
    console.error('Login route error:', error)
    return c.json({ error: 'خطأ في الخادم: ' + String(error) }, 500)
  }
})

// API للتحقق من الجلسة
app.get('/api/me', async (c) => {
  try {
    const authHeader = c.req.header('Authorization')
    const token = authHeader?.replace('Bearer ', '')
    
    if (!token) {
      return c.json({ error: 'غير مصرح' }, 401)
    }
    
    const session = verifySession(token)
    
    if (!session) {
      return c.json({ error: 'جلسة منتهية الصلاحية' }, 401)
    }
    
    return c.json({ user: session })
  } catch (error) {
    return c.json({ error: 'خطأ في التحقق من الجلسة' }, 500)
  }
})

// API routes للأطباء
app.get('/api/doctors', async (c) => {
  try {
    const authHeader = c.req.header('Authorization')
    const token = authHeader?.replace('Bearer ', '')
    
    if (!token) {
      return c.json({ error: 'غير مصرح' }, 401)
    }
    
    const session = verifySession(token)
    if (!session) {
      return c.json({ error: 'جلسة منتهية الصلاحية' }, 401)
    }
    
    const query = c.req.query()
    const filters = {
      region: query.region,
      specialty: query.specialty,
      day: query.day,
      street: query.street,
      hospital: query.hospital
    }
    
    const doctors = await getDoctors(c, session.id, filters)
    return c.json({ doctors })
  } catch (error) {
    console.error('Get doctors error:', error)
    return c.json({ error: 'خطأ في جلب بيانات الأطباء' }, 500)
  }
})

app.post('/api/doctors', async (c) => {
  try {
    const authHeader = c.req.header('Authorization')
    const token = authHeader?.replace('Bearer ', '')
    
    if (!token) {
      return c.json({ error: 'غير مصرح' }, 401)
    }
    
    const session = verifySession(token)
    if (!session) {
      return c.json({ error: 'جلسة منتهية الصلاحية' }, 401)
    }
    
    const doctorData = await c.req.json()
    doctorData.rep_id = session.id
    
    const doctor = await addDoctor(c, doctorData)
    
    if (!doctor) {
      return c.json({ error: 'فشل في إضافة الطبيب' }, 400)
    }
    
    return c.json({ doctor })
  } catch (error) {
    console.error('Add doctor error:', error)
    return c.json({ error: 'خطأ في إضافة الطبيب' }, 500)
  }
})

// API للتخصصات والمناطق
app.get('/api/specialties', async (c) => {
  try {
    const specialties = await getSpecialties(c)
    return c.json({ specialties })
  } catch (error) {
    return c.json({ error: 'خطأ في جلب التخصصات' }, 500)
  }
})

app.get('/api/regions', async (c) => {
  try {
    const regions = await getRegions(c)
    return c.json({ regions })
  } catch (error) {
    return c.json({ error: 'خطأ في جلب المناطق' }, 500)
  }
})

// API للإحصائيات
app.get('/api/dashboard', async (c) => {
  try {
    const authHeader = c.req.header('Authorization')
    const token = authHeader?.replace('Bearer ', '')
    
    if (!token) {
      return c.json({ error: 'غير مصرح' }, 401)
    }
    
    const session = verifySession(token)
    if (!session) {
      return c.json({ error: 'جلسة منتهية الصلاحية' }, 401)
    }
    
    const stats = await getDashboardStats(c, session.id)
    return c.json({ stats })
  } catch (error) {
    return c.json({ error: 'خطأ في جلب الإحصائيات' }, 500)
  }
})

// الصفحة الرئيسية
app.get('/', (c) => {
  return c.render(
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">
              🏥 نظام إدارة المندوبين العلميين
            </h1>
            <p className="text-lg text-gray-600">
              منصة شاملة لإدارة وتنظيم زيارات المندوبين العلميين والمسوقين الميدانيين
            </p>
          </div>
          
          {/* Login Section */}
          <div id="login-section" className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-6 mb-8">
            <h2 className="text-2xl font-semibold text-center text-gray-800 mb-6">
              تسجيل الدخول
            </h2>
            <form id="login-form">
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  اسم المستخدم
                </label>
                <input
                  type="text"
                  id="username"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="أدخل اسم المستخدم"
                />
              </div>
              <div className="mb-6">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  كلمة المرور
                </label>
                <input
                  type="password"
                  id="password"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="أدخل كلمة المرور"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
              >
                دخول
              </button>
            </form>
            <div id="login-error" className="mt-4 text-red-600 text-sm hidden"></div>
          </div>
          
          {/* Main App - Hidden initially */}
          <div id="main-app" className="hidden">
            {/* Dashboard */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-3xl font-bold text-blue-600" id="total-doctors">0</div>
                <div className="text-gray-600">إجمالي الأطباء</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-3xl font-bold text-green-600" id="visits-month">0</div>
                <div className="text-gray-600">زيارات هذا الشهر</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-3xl font-bold text-purple-600" id="active-plans">0</div>
                <div className="text-gray-600">خطط نشطة</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-3xl font-bold text-orange-600" id="today-visits">0</div>
                <div className="text-gray-600">زيارات اليوم</div>
              </div>
            </div>
            
            {/* Navigation */}
            <div className="flex flex-wrap gap-4 mb-6">
              <button onclick="showSection('doctors')" className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700">
                إدارة الأطباء
              </button>
              <button onclick="showSection('add-doctor')" className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700">
                إضافة طبيب جديد
              </button>
              <button onclick="showSection('plans')" className="bg-purple-600 text-white px-6 py-2 rounded-md hover:bg-purple-700">
                خطط الزيارات
              </button>
              <button onclick="logout()" className="bg-red-600 text-white px-6 py-2 rounded-md hover:bg-red-700">
                تسجيل خروج
              </button>
            </div>
            
            {/* Sections */}
            <div id="doctors-section" className="section hidden bg-white rounded-lg shadow-md p-6">
              {/* Filters */}
              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-4">فلترة الأطباء</h3>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  <input type="text" id="filter-region" placeholder="المنطقة" className="border rounded px-3 py-2" />
                  <input type="text" id="filter-specialty" placeholder="التخصص" className="border rounded px-3 py-2" />
                  <input type="text" id="filter-street" placeholder="الشارع" className="border rounded px-3 py-2" />
                  <input type="text" id="filter-hospital" placeholder="المستشفى" className="border rounded px-3 py-2" />
                  <button onclick="filterDoctors()" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    بحث
                  </button>
                </div>
              </div>
              
              <div id="doctors-list"></div>
            </div>
            
            <div id="add-doctor-section" className="section hidden bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold mb-4">إضافة طبيب جديد</h3>
              <form id="add-doctor-form" className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input type="text" name="name" placeholder="اسم الطبيب *" required className="border rounded px-3 py-2" />
                <select name="specialty" required className="border rounded px-3 py-2">
                  <option value="">اختر التخصص *</option>
                </select>
                <input type="text" name="clinic_name" placeholder="اسم العيادة" className="border rounded px-3 py-2" />
                <input type="text" name="hospital" placeholder="المستشفى" className="border rounded px-3 py-2" />
                <input type="text" name="address" placeholder="العنوان" className="border rounded px-3 py-2" />
                <input type="text" name="street" placeholder="الشارع" className="border rounded px-3 py-2" />
                <select name="region" required className="border rounded px-3 py-2">
                  <option value="">اختر المنطقة *</option>
                </select>
                <input type="text" name="phone" placeholder="هاتف العيادة" className="border rounded px-3 py-2" />
                <input type="text" name="mobile" placeholder="موبايل" className="border rounded px-3 py-2" />
                <input type="email" name="email" placeholder="البريد الإلكتروني" className="border rounded px-3 py-2" />
                <textarea name="notes" placeholder="ملاحظات" className="border rounded px-3 py-2 col-span-2" rows="3"></textarea>
                
                <div className="col-span-2">
                  <label className="block text-gray-700 font-bold mb-2">أيام الزيارة:</label>
                  <div className="grid grid-cols-4 gap-2">
                    {['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'].map(day => (
                      <label key={day} className="flex items-center">
                        <input type="checkbox" name="visit_days" value={day} className="mr-2" />
                        {day}
                      </label>
                    ))}
                  </div>
                </div>
                
                <button type="submit" className="col-span-2 bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700">
                  إضافة الطبيب
                </button>
              </form>
            </div>
            
            <div id="plans-section" className="section hidden bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold mb-4">خطط الزيارات</h3>
              <div id="plans-list"></div>
            </div>
          </div>
        </div>
      </div>
      
      <script src="/static/app.js"></script>
    </div>
  )
})

export default app
